const Re='@import"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap";#deepguard-panel{position:fixed;z-index:2147483647;width:300px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 8px 32px #0000001f,0 2px 8px #2a7efb14;font-family:Poppins,-apple-system,sans-serif;font-size:13px;color:#1e293b;overflow:hidden;animation:dg-slideIn .28s cubic-bezier(.34,1.56,.64,1);-webkit-user-select:none;-moz-user-select:none;user-select:none}#deepguard-panel.dragging{transition:none}@keyframes dg-slideIn{0%{opacity:0;transform:scale(.88) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}.dg-header{display:flex;align-items:center;justify-content:space-between;padding:11px 13px 10px;background:#fff}.dg-header-left{display:flex;align-items:center;gap:5px}.dg-logo{width:24px;height:24px;flex-shrink:0}.dg-logo img{width:24px;height:24px;display:block}.dg-title{font-size:13px;font-weight:700;color:#2a7efb;letter-spacing:-.2px}.dg-subtitle{font-size:9px;color:#94a3b8;font-weight:500;letter-spacing:0px;margin-top:-1px}.dg-close{width:24px;height:24px;color:#94a3b8;cursor:pointer;border:none;background:#fff;display:flex;align-items:center;justify-content:center;font-size:15px;transition:color .15s;line-height:1;padding:0}.dg-close:hover{color:#ef4444}.dg-body{padding:14px 13px}.dg-loading{display:flex;flex-direction:column;align-items:center;padding:10px 0 14px}.dg-orbital{position:relative;width:160px;height:160px}.dg-orbital-svg{width:160px;height:160px;animation:dg-orbit 1.4s linear infinite}@keyframes dg-orbit{to{transform:rotate(360deg)}}.dg-orbital-track{fill:none;stroke:#dbeafe;stroke-width:9}.dg-orbital-comet{fill:none;stroke:url(#dg-comet-grad);stroke-width:9;stroke-linecap:round}.dg-orbital-center{position:absolute;top:0;right:0;bottom:0;left:0;display:flex;align-items:center;justify-content:center}.dg-orbital-label{font-size:15px;font-weight:600;color:#475569;letter-spacing:-.2px}.dg-score-wrapper{display:flex;flex-direction:column;align-items:center;gap:10px;margin-bottom:13px}.dg-ring-container{position:relative;width:120px;height:120px;flex-shrink:0}.dg-ring-svg{width:120px;height:120px;transform:rotate(-90deg);display:block}.dg-ring-track{fill:none;stroke:#f1f5f9;stroke-width:8}.dg-ring-fill{fill:none;stroke-width:8;stroke-linecap:round}.dg-ring-label{position:absolute;top:0;right:0;bottom:0;left:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px}.dg-ring-score{font-size:26px;font-weight:800;letter-spacing:-1px;line-height:1}.dg-ring-pct{font-size:10px;color:#94a3b8;font-weight:500}.dg-score-meta{display:flex;flex-direction:column;align-items:center;gap:4px}.dg-verdict{display:inline-flex;align-items:center;gap:5px;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.3px}.dg-verdict.fake{background:#fee2e2;border:1px solid #fca5a5;color:#ef4444}.dg-verdict.real{background:#dcfce7;border:1px solid #86efac;color:#16a34a}.dg-bars{display:flex;flex-direction:column;gap:7px;margin-bottom:12px}.dg-bar-row{display:flex;flex-direction:column;gap:3px}.dg-bar-label{display:flex;justify-content:space-between;font-size:10px;color:#94a3b8;font-weight:500}.dg-bar-label span:last-child{font-weight:700;color:#64748b}.dg-bar-track{height:5px;border-radius:3px;background:#f1f5f9;overflow:hidden}.dg-bar-fill{height:100%;border-radius:3px;width:0%;transition:width 1.2s cubic-bezier(.4,0,.2,1)}.dg-bar-fill.fake{background:linear-gradient(90deg,#ef4444,#f97316)}.dg-bar-fill.real{background:linear-gradient(90deg,#22c55e,#2a7efb)}.dg-section-label{font-size:9.5px;font-weight:600;color:#cbd5e1;text-transform:uppercase;letter-spacing:.6px;margin-bottom:7px}.dg-analysis-list{display:flex;flex-direction:column;gap:5px}.dg-analysis-item{display:flex;align-items:flex-start;gap:6px;font-size:10.5px;color:#64748b;line-height:1.4}.dg-check{width:14px;height:14px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:8px;flex-shrink:0;margin-top:1px}.dg-check.ok{background:#dcfce7;color:#16a34a}.dg-check.warn{background:#fee2e2;color:#ef4444}.dg-footer-bar{padding:7px 13px;border-top:1px solid #f1f5f9;font-size:9.5px;color:#cbd5e1;background:#f8fafc;font-weight:500}.dg-divider{height:1px;background:#f1f5f9;margin:12px 0}.dg-countdown{display:flex;flex-direction:column;align-items:center;gap:8px;padding:6px 0}.dg-countdown-num{font-size:48px;font-weight:800;color:#2a7efb;line-height:1;animation:dg-countPulse 1s ease infinite}@keyframes dg-countPulse{0%,to{transform:scale(1);opacity:1}50%{transform:scale(1.06);opacity:.85}}.dg-countdown-label{font-size:11.5px;color:#64748b;font-weight:500;text-align:center}.dg-recording{display:flex;flex-direction:column;align-items:center;gap:10px;padding:6px 0}.dg-rec-dot{width:16px;height:16px;border-radius:50%;background:#ef4444;animation:dg-recPulse 1s ease infinite}@keyframes dg-recPulse{0%{box-shadow:0 0 #ef444480}70%{box-shadow:0 0 0 10px #ef444400}to{box-shadow:0 0 #ef444400}}.dg-rec-label{font-size:12px;font-weight:600;color:#ef4444}.dg-rec-time{font-size:10px;color:#94a3b8;font-weight:500}.dg-rec-bar{width:90%;height:4px;border-radius:2px;background:#fee2e2;overflow:hidden}.dg-rec-bar-fill{height:100%;background:linear-gradient(90deg,#fca5a5 25%,#ef4444,#fca5a5 75%);background-size:200% 100%;border-radius:2px;animation:dg-shimmerMove 1.4s infinite}',I="deepguard-panel",se="deepguard-panel-styles";function Le(){if(document.getElementById(se))return;const e=document.createElement("style");e.id=se,e.textContent=Re,document.head.appendChild(e)}function Te(e){return`
    <div class="dg-header">
      <div class="dg-header-left">
        <div class="dg-logo"><img src="${e}" alt="DeepGuard" /></div>
        <div>
          <div class="dg-title">DeepGuard</div>
        </div>
      </div>
      <button class="dg-close" id="dg-close-btn" title="Close">✕</button>
    </div>
  `}function Be(){return`
    <div class="dg-loading">
      <div class="dg-orbital">
        <svg class="dg-orbital-svg" viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="dg-comet-grad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%"   stop-color="#2A7EFB" stop-opacity="0"/>
              <stop offset="60%"  stop-color="#2A7EFB" stop-opacity="0.6"/>
              <stop offset="100%" stop-color="#2A7EFB" stop-opacity="1"/>
            </linearGradient>
          </defs>
          <circle class="dg-orbital-track" cx="80" cy="80" r="68"/>
          <circle class="dg-orbital-comet" cx="80" cy="80" r="68"
            stroke-dasharray="140 290"
          />
        </svg>
        <div class="dg-orbital-center">
          <span class="dg-orbital-label">Loading</span>
        </div>
      </div>
    </div>
  `}function T(e,t){var o;Le(),K();const i=chrome.runtime.getURL("icons/icon128.png"),n=document.createElement("div");if(n.id=I,t)n.style.left=`${Math.min(t.x,window.innerWidth-320)}px`,n.style.top=`${Math.min(t.y,window.innerHeight-100)}px`;else if(e){const r=e.getBoundingClientRect(),a=Math.min(r.right+10,window.innerWidth-320),s=Math.max(r.top,10);n.style.left=`${a+window.scrollX}px`,n.style.top=`${s+window.scrollY}px`,n.style.position="absolute"}else n.style.right="20px",n.style.top="80px";return n.innerHTML=`
    ${Te(i)}
    <div class="dg-body">${Be()}</div>
  `,document.body.appendChild(n),Se(n),(o=document.getElementById("dg-close-btn"))==null||o.addEventListener("click",K),n}function K(){var e;(e=document.getElementById(I))==null||e.remove()}function v(e){const t=document.querySelector(`#${I} .dg-body`);t&&(t.innerHTML=`
    <div class="dg-countdown">
      <div class="dg-countdown-num">${e}</div>
      <div class="dg-countdown-label">Recording starts in ${e} second${e!==1?"s":""}</div>
    </div>
  `)}function w(e,t){const i=document.querySelector(`#${I} .dg-body`);if(!i)return;const n=Math.max(0,t-e),o=e>=t;i.innerHTML=`
    <div class="dg-recording">
      <div class="dg-rec-dot" ${o?'style="background-color: #f59e0b; animation: none;"':""}></div>
      <div class="dg-rec-label">${o?"⏳ Analyzing AI...":"🎙️ Recording…"}</div>
      <div class="dg-rec-time">${o?"Please wait":n+"s remaining"}</div>
      <div class="dg-rec-bar">
        <div class="dg-rec-bar-fill" style="width: ${o?"100":e/t*100}%"></div>
      </div>
    </div>
  `}function B(e){const t=document.querySelector(`#${I} .dg-body`);if(!t)return;const i=e.label==="FAKE",n=e.confidence,o=52,r=2*Math.PI*o,a=r*(1-n/100),s=i?"#ef4444":"#22c55e";t.innerHTML=`
    <div class="dg-score-wrapper">
      <div class="dg-ring-container">
        <svg class="dg-ring-svg" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="dg-ring-grad-fake" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%"   stop-color="#f97316"/>
              <stop offset="100%" stop-color="#ef4444"/>
            </linearGradient>
            <linearGradient id="dg-ring-grad-real" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%"   stop-color="#22c55e"/>
              <stop offset="100%" stop-color="#2A7EFB"/>
            </linearGradient>
          </defs>
          <circle class="dg-ring-track" cx="60" cy="60" r="${o}"/>
          <circle
            class="dg-ring-fill"
            id="dg-ring-anim"
            cx="60" cy="60" r="${o}"
            stroke="${i?"url(#dg-ring-grad-fake)":"url(#dg-ring-grad-real)"}"
            stroke-dasharray="${r}"
            stroke-dashoffset="${r}"
          />
        </svg>
        <div class="dg-ring-label">
          <span class="dg-ring-score" id="dg-score-num" style="color:${s}">0</span>
          <span class="dg-ring-pct">% confidence</span>
        </div>
      </div>

      <div class="dg-score-meta">
        <div class="dg-verdict ${i?"fake":"real"}">
          ${i?"⚠ DEEPFAKE":"✓ AUTHENTIC"}
        </div>
      </div>
    </div>

    <div class="dg-bars">
      <div class="dg-bar-row">
        <div class="dg-bar-label">
          <span>Fake Probability</span>
          <span id="dg-fake-pct">0%</span>
        </div>
        <div class="dg-bar-track">
          <div class="dg-bar-fill fake" id="dg-fake-bar" style="width:0%"></div>
        </div>
      </div>
      <div class="dg-bar-row">
        <div class="dg-bar-label">
          <span>Real Probability</span>
          <span id="dg-real-pct">0%</span>
        </div>
        <div class="dg-bar-track">
          <div class="dg-bar-fill real" id="dg-real-bar" style="width:0%"></div>
        </div>
      </div>
    </div>

    <div class="dg-divider"></div>

    <div class="dg-section-label">Detailed Analysis</div>
    <div class="dg-analysis-list">
      ${e.details.analysis_points.map(c=>`
        <div class="dg-analysis-item">
          <div class="dg-check ${i?"warn":"ok"}">${i?"!":"✓"}</div>
          <span>${c}</span>
        </div>`).join("")}
    </div>
  `,requestAnimationFrame(()=>{requestAnimationFrame(()=>{const c=document.getElementById("dg-ring-anim");c&&(c.style.transition="stroke-dashoffset 1.2s cubic-bezier(0.4, 0, 0.2, 1)",c.style.strokeDashoffset=String(a));const _=document.getElementById("dg-fake-bar"),oe=document.getElementById("dg-real-bar");_&&(_.style.width=`${e.scores.FAKE}%`),oe&&(oe.style.width=`${e.scores.REAL}%`);const Ee=1200,ke=performance.now(),z=document.getElementById("dg-score-num"),O=document.getElementById("dg-fake-pct"),D=document.getElementById("dg-real-pct");function Me(V){return 1-Math.pow(1-V,3)}function re(V){const Ae=V-ke,ae=Math.min(Ae/Ee,1),G=Me(ae),Ie=G*n,$e=G*e.scores.FAKE,Ce=G*e.scores.REAL;z&&(z.textContent=Ie.toFixed(1)),O&&(O.textContent=$e.toFixed(1)+"%"),D&&(D.textContent=Ce.toFixed(1)+"%"),ae<1?requestAnimationFrame(re):(z&&(z.textContent=n.toFixed(1)),O&&(O.textContent=e.scores.FAKE.toFixed(1)+"%"),D&&(D.textContent=e.scores.REAL.toFixed(1)+"%"))}requestAnimationFrame(re)})})}function S(e){const t=document.querySelector(`#${I} .dg-body`);t&&(t.innerHTML=`
    <div style="text-align:center; padding: 14px 0; color: #ef4444;">
      <div style="font-size: 26px; margin-bottom: 8px;">⚠️</div>
      <div style="font-size: 12px; font-weight: 700; margin-bottom: 4px; color:#1e293b;">Analysis Failed</div>
      <div style="font-size: 10.5px; color: #94a3b8;">${e}</div>
    </div>
  `)}function Se(e){let t=0,i=0,n=0,o=0;e.addEventListener("mousedown",r=>{if(r.target.id==="dg-close-btn")return;e.classList.add("dragging"),t=r.clientX,i=r.clientY,n=parseInt(e.style.left||"0",10),o=parseInt(e.style.top||"0",10);const a=c=>{e.style.left=`${n+c.clientX-t}px`,e.style.top=`${o+c.clientY-i}px`,e.style.right="auto"},s=()=>{e.classList.remove("dragging"),document.removeEventListener("mousemove",a),document.removeEventListener("mouseup",s)};document.addEventListener("mousemove",a),document.addEventListener("mouseup",s),r.preventDefault()})}const N="data-dg-injected",de=80;let C=!1,b=null;function le(){C||(C=!0,ze(),Oe())}function _e(){C=!1,b==null||b.disconnect(),b=null,document.querySelectorAll(`[${N}]`).forEach(e=>{e.removeAttribute(N)}),document.querySelectorAll(".dg-guard-badge").forEach(e=>e.remove()),K()}function ze(){document.querySelectorAll("img").forEach(e=>{e.complete&&e.naturalWidth>0?Y(e):e.addEventListener("load",()=>Y(e),{once:!0})})}function Y(e){if(!C||e.hasAttribute(N)||e.width<de||e.height<de||!e.src||e.src.startsWith("data:image/svg"))return;e.setAttribute(N,"true");const t=document.createElement("div");t.className="dg-guard-badge",t.style.cssText=`
    position: absolute;
    bottom: 6px;
    right: 6px;
    z-index: 2147483647;
    cursor: pointer;
    transition: transform 0.15s ease;
  `;let i;try{i=`<img src="${chrome.runtime.getURL("icons/icon128.png")}" alt="DeepGuard" style="width:18px;height:20px;display:block;border-radius:4px;" />`}catch{i='<svg viewBox="0 0 24 24" width="18" height="20" fill="#2A7EFB"><path d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm-1.06 13.54L7.4 12l1.41-1.41 2.12 2.12 4.24-4.24 1.41 1.41-5.64 5.66z"/></svg>'}t.innerHTML=i,t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.1)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)"}),t.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),De(e)});const n=e.parentElement;n&&(getComputedStyle(n).position==="static"&&(n.style.position="relative"),n.appendChild(t))}function Oe(){b=new MutationObserver(e=>{if(C)for(const t of e)t.addedNodes.forEach(i=>{var o;if(i.nodeType!==1)return;const n=i;n.tagName==="IMG"&&Y(n),(o=n.querySelectorAll)==null||o.call(n,"img").forEach(r=>Y(r))})}),b.observe(document.body,{childList:!0,subtree:!0})}async function De(e){T(e);try{let t;try{t=await Fe(e.currentSrc||e.src)}catch{t=await Pe(e)}B(t)}catch(t){S(t instanceof Error?t.message:"Analysis failed.")}}function Fe(e){return new Promise((t,i)=>{chrome.runtime.sendMessage({type:"ANALYZE_IMAGE_URL",payload:{url:e}},n=>{if(chrome.runtime.lastError){i(chrome.runtime.lastError);return}n!=null&&n.success?t(n):i(new Error((n==null?void 0:n.error)||"Backend error"))})})}function Pe(e){const t=document.createElement("canvas");t.width=e.naturalWidth||e.width,t.height=e.naturalHeight||e.height;const i=t.getContext("2d");if(!i)throw new Error("Canvas not supported");i.drawImage(e,0,0);const n=t.toDataURL("image/png");return new Promise((o,r)=>{chrome.runtime.sendMessage({type:"ANALYZE_IMAGE_BASE64",payload:{base64:n}},a=>{if(chrome.runtime.lastError){r(chrome.runtime.lastError);return}a!=null&&a.success?o(a):r(new Error((a==null?void 0:a.error)||"Backend error"))})})}const Ue="dg-region-overlay",Ne="dg-select-box",Z="dg-cursor-style";let R=!1,E=0,k=0,p=null,d=null,F=null;function Ye(){te(),He(),Ve()}function He(){let e=document.getElementById(Z);e||(e=document.createElement("style"),e.id=Z,document.head.appendChild(e)),e.textContent=`
    html, html * {
      cursor: crosshair !important;
    }
  `}function Xe(){var e;(e=document.getElementById(Z))==null||e.remove()}function Ve(){p=document.createElement("div"),p.id=Ue,p.style.cssText=`
    position: fixed;
    inset: 0;
    z-index: 2147483646;
    user-select: none;
  `,d=document.createElement("div"),d.id=Ne,d.style.cssText=`
    position: fixed;
    border: 2px solid #6C63FF;
    background: rgba(108,99,255,0.08);
    display: none;
    pointer-events: none;
    z-index: 2147483647;
    border-radius: 4px;
    box-shadow: 0 0 0 1px rgba(108,99,255,0.3), inset 0 0 20px rgba(108,99,255,0.05);
  `,document.body.appendChild(d),p.addEventListener("mousedown",Ge),document.addEventListener("mousemove",ce),document.addEventListener("mouseup",ge),document.body.appendChild(p),document.addEventListener("keydown",ue)}function Ge(e){R=!0,E=e.clientX,k=e.clientY,d&&(d.style.display="block",d.style.left=`${E}px`,d.style.top=`${k}px`,d.style.width="0",d.style.height="0"),e.preventDefault()}function ce(e){if(!R||!d)return;const t=Math.min(e.clientX,E),i=Math.min(e.clientY,k),n=Math.abs(e.clientX-E),o=Math.abs(e.clientY-k);d.style.left=`${t}px`,d.style.top=`${i}px`,d.style.width=`${n}px`,d.style.height=`${o}px`}async function ge(e){if(!R)return;R=!1;const t=Math.min(e.clientX,E),i=Math.min(e.clientY,k),n=Math.abs(e.clientX-E),o=Math.abs(e.clientY-k);te(),!(n<20||o<20)&&(T(null,{x:Math.min(t+n+12,window.innerWidth-340),y:Math.max(i,10)}),await qe(t,i,n,o))}function ue(e){e.key==="Escape"&&te()}async function qe(e,t,i,n){let o=0;const r=5,a=async()=>{if(o++,o>r){J();return}try{const s=await We(e,t,i,n),c=await je(s);B(c)}catch(s){S(s instanceof Error?s.message:"Region capture failed"),J()}};await a(),F=window.setInterval(a,2e3)}function J(){F!==null&&(clearInterval(F),F=null)}async function We(e,t,i,n){return new Promise((o,r)=>{chrome.runtime.sendMessage({type:"CAPTURE_REGION",payload:{x:e,y:t,w:i,h:n}},a=>{if(chrome.runtime.lastError)return r(new Error(chrome.runtime.lastError.message));a!=null&&a.base64?o(a.base64):r(new Error((a==null?void 0:a.error)||"Capture failed"))})})}async function je(e){return new Promise((t,i)=>{chrome.runtime.sendMessage({type:"ANALYZE_IMAGE_BASE64",payload:{base64:e}},n=>{if(chrome.runtime.lastError)return i(new Error(chrome.runtime.lastError.message));n!=null&&n.success?t(n):i(new Error((n==null?void 0:n.error)||"Analysis failed"))})})}function te(){R=!1,J(),p==null||p.remove(),p=null,d==null||d.remove(),d=null,Xe(),document.removeEventListener("mousemove",ce),document.removeEventListener("mouseup",ge),document.removeEventListener("keydown",ue)}const q=10;let P=null;chrome.runtime.onMessage.addListener(e=>{e.type==="AUDIO_CAPTURE_RESULT"&&(P&&(clearInterval(P),P=null),e.success&&e.result?B(e.result):S(e.error||"Audio capture failed. Make sure the tab is playing audio."))});function Ke(){T(null,{x:window.innerWidth-350,y:80});let e=5;v(e);const t=setInterval(()=>{e--,e<=0?(clearInterval(t),Ze()):v(e)},1e3)}function Ze(){w(0,q);let e=0;P=setInterval(()=>{e++,w(e,q)},1e3),chrome.runtime.sendMessage({type:"START_TAB_AUDIO_CAPTURE",payload:{duration:q}},()=>{chrome.runtime.lastError})}const W=15,Je="dg-video-overlay",Qe="dg-video-select-box",Q="dg-video-cursor-style";let L=!1,M=0,A=0,g=null,l=null,U=null;chrome.runtime.onMessage.addListener(e=>{e.type==="VIDEO_CAPTURE_RESULT"&&(U&&(clearInterval(U),U=null),e.success&&e.result?B(e.result):S(e.error||"Video capture failed. Make sure the tab is active."))});function et(){ne(),tt(),it()}function tt(){let e=document.getElementById(Q);e||(e=document.createElement("style"),e.id=Q,document.head.appendChild(e)),e.textContent=`
    html, html * {
      cursor: crosshair !important;
    }
  `}function nt(){var e;(e=document.getElementById(Q))==null||e.remove()}function it(){g=document.createElement("div"),g.id=Je,g.style.cssText=`
    position: fixed;
    inset: 0;
    z-index: 2147483646;
    user-select: none;
  `;const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 16px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #2A7EFB, #1a5dc7);
    color: white;
    padding: 10px 24px;
    border-radius: 12px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px;
    font-weight: 600;
    z-index: 2147483647;
    pointer-events: none;
    box-shadow: 0 4px 20px rgba(42,126,251,0.4);
    display: flex;
    align-items: center;
    gap: 8px;
  `,e.innerHTML=`
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
      <path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
    </svg>
    Drag to select the video area to record • Press ESC to cancel
  `,g.appendChild(e),l=document.createElement("div"),l.id=Qe,l.style.cssText=`
    position: fixed;
    border: 2px solid #2A7EFB;
    background: rgba(42,126,251,0.08);
    display: none;
    pointer-events: none;
    z-index: 2147483647;
    border-radius: 4px;
    box-shadow: 0 0 0 1px rgba(42,126,251,0.3), inset 0 0 20px rgba(42,126,251,0.05);
  `,document.body.appendChild(l),g.addEventListener("mousedown",ot),document.addEventListener("mousemove",pe),document.addEventListener("mouseup",fe),document.body.appendChild(g),document.addEventListener("keydown",me)}function ot(e){L=!0,M=e.clientX,A=e.clientY,l&&(l.style.display="block",l.style.left=`${M}px`,l.style.top=`${A}px`,l.style.width="0",l.style.height="0"),e.preventDefault()}function pe(e){if(!L||!l)return;const t=Math.min(e.clientX,M),i=Math.min(e.clientY,A),n=Math.abs(e.clientX-M),o=Math.abs(e.clientY-A);l.style.left=`${t}px`,l.style.top=`${i}px`,l.style.width=`${n}px`,l.style.height=`${o}px`}function fe(e){if(!L)return;L=!1;const t=Math.min(e.clientX,M),i=Math.min(e.clientY,A),n=Math.abs(e.clientX-M),o=Math.abs(e.clientY-A);if(ne(),n<20||o<20)return;const r=Math.max(document.documentElement.clientWidth||0,window.innerWidth||0),a=Math.max(document.documentElement.clientHeight||0,window.innerHeight||0),s={x:Math.max(0,t/r),y:Math.max(0,i/a),w:Math.min(1,n/r),h:Math.min(1,o/a)};T(null,{x:Math.min(t+n+12,window.innerWidth-340),y:Math.max(i,10)}),rt(s)}function me(e){e.key==="Escape"&&ne()}function rt(e){let t=5;v(t);const i=setInterval(()=>{t--,t<=0?(clearInterval(i),at(e)):v(t)},1e3)}function at(e){w(0,W);let t=0;U=setInterval(()=>{t++,w(t,W)},1e3),chrome.runtime.sendMessage({type:"START_TAB_VIDEO_CAPTURE",payload:{duration:W,bbox:e}},()=>{chrome.runtime.lastError})}function ne(){L=!1,g==null||g.remove(),g=null,l==null||l.remove(),l=null,nt(),document.removeEventListener("mousemove",pe),document.removeEventListener("mouseup",fe),document.removeEventListener("keydown",me)}const j=15,st=6e4,he="dg-cam-badge",ee="dg-cam-overlay";let f=!1,$=null,x=null,m=null,u=!1,y=null,h=null;chrome.runtime.onMessage.addListener(e=>{e.type==="VIDEO_CAPTURE_RESULT"&&f&&(x&&(clearInterval(x),x=null),e.success&&e.result?B(e.result):S(e.error||"Cam monitor capture failed."),f&&(H("next"),$=setTimeout(()=>{f&&ie()},st)))});function xe(){f||(f=!0,ct(),ie())}function ye(){f=!1,$&&(clearTimeout($),$=null),x&&(clearInterval(x),x=null),be(),X(),y=null;try{chrome.storage.session.set({camMonitorOn:!1})}catch{}}function ie(){if(!f)return;const e=lt();if(!e){H("no-video"),y=null,X(),$=setTimeout(()=>{f&&ie()},1e4);return}y=e,u&&ve();const t=e.getBoundingClientRect(),i=Math.max(document.documentElement.clientWidth||0,window.innerWidth||0),n=Math.max(document.documentElement.clientHeight||0,window.innerHeight||0),o={x:Math.max(0,t.left/i),y:Math.max(0,t.top/n),w:Math.min(1,t.width/i),h:Math.min(1,t.height/n)};T(null,{x:Math.min(t.right+12,window.innerWidth-340),y:Math.max(t.top,10)}),H("scanning");let r=3;v(r);const a=setInterval(()=>{r--,r<=0?(clearInterval(a),dt(o)):v(r)},1e3)}function dt(e){w(0,j);let t=0;x=setInterval(()=>{t++,w(t,j)},1e3),chrome.runtime.sendMessage({type:"START_TAB_VIDEO_CAPTURE",payload:{duration:j,bbox:e}},()=>{chrome.runtime.lastError})}function lt(){const e=Array.from(document.querySelectorAll("video"));if(e.length===0)return null;let t=null,i=0;for(const n of e){const o=n.getBoundingClientRect(),r=o.width*o.height;r>i&&o.width>50&&o.height>50&&!n.paused&&(i=r,t=n)}if(!t)for(const n of e){const o=n.getBoundingClientRect(),r=o.width*o.height;r>i&&o.width>50&&o.height>50&&(i=r,t=n)}return t}function ct(){be(),m=document.createElement("div"),m.id=he,m.style.cssText=`
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 2147483647;
    background: linear-gradient(135deg, #2A7EFB, #1a5dc7);
    color: white;
    padding: 10px 18px;
    border-radius: 14px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 12px;
    font-weight: 600;
    box-shadow: 0 4px 24px rgba(42,126,251,0.5);
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: default;
    transition: all 0.3s ease;
    user-select: none;
  `,H("scanning"),document.body.appendChild(m)}function H(e){if(!m)return;const t={scanning:'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3" fill="white"/></svg>',next:'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>',"no-video":'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'},i={scanning:"🔴 Scanning...",next:"⏳ Next in 60s","no-video":"⚠ No video found"};m.innerHTML=`
    <span style="display:flex;align-items:center;gap:6px;">${t[e]} ${i[e]}</span>
    <span style="width:1px;height:16px;background:rgba(255,255,255,0.25);margin:0 2px;"></span>
    <button id="dg-overlay-toggle" title="${u?"Hide capture area":"Show capture area"}" style="
      display:flex;align-items:center;justify-content:center;
      width:28px;height:28px;border-radius:8px;border:none;
      background:${u?"rgba(255,255,255,0.25)":"transparent"};
      cursor:pointer;transition:background 0.2s;
    "></button>
    <button id="dg-stop-btn" title="Stop monitoring" style="
      display:flex;align-items:center;justify-content:center;
      width:28px;height:28px;border-radius:8px;border:none;
      background:rgba(239,68,68,0.8);
      cursor:pointer;transition:background 0.2s;
    "><svg width="12" height="12" viewBox="0 0 24 24" fill="white"><rect x="6" y="6" width="12" height="12" rx="2"/></svg></button>
  `;const n=document.getElementById("dg-overlay-toggle");n&&(we(),n.addEventListener("click",r=>{r.stopPropagation(),gt()}));const o=document.getElementById("dg-stop-btn");o&&o.addEventListener("click",r=>{r.stopPropagation(),ye()})}function be(){var e;(e=document.getElementById(he))==null||e.remove(),m=null}function ve(){if(X(),!y)return;const e=document.createElement("div");e.id=ee,e.style.cssText=`
    position: fixed;
    z-index: 2147483646;
    pointer-events: none;
    border: 2.5px solid #2A7EFB;
    border-radius: 8px;
    background: rgba(42, 126, 251, 0.06);
    box-shadow: 0 0 0 1px rgba(42,126,251,0.15), inset 0 0 20px rgba(42,126,251,0.05);
    transition: left 0.15s ease, top 0.15s ease, width 0.15s ease, height 0.15s ease;
  `;const t=["top-left","top-right","bottom-left","bottom-right"];for(const r of t){const a=document.createElement("div"),[s,c]=r.split("-");a.style.cssText=`
      position: absolute;
      width: 14px;
      height: 14px;
      border-color: #2A7EFB;
      border-style: solid;
      border-width: 0;
      border-${s}-width: 3px;
      border-${c}-width: 3px;
      ${s}: -2px;
      ${c}: -2px;
      border-${s==="top"?s:"bottom"}-${c==="left"?c:"right"}-radius: 4px;
    `,e.appendChild(a)}const i=document.createElement("div");i.className="dg-overlay-label",i.style.cssText=`
    position: absolute;
    bottom: -26px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(42,126,251,0.9);
    color: white;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 10px;
    font-weight: 600;
    padding: 3px 10px;
    border-radius: 6px;
    white-space: nowrap;
    letter-spacing: 0.3px;
  `,e.appendChild(i);const n=document.createElement("div");if(n.style.cssText=`
    position: absolute;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #2A7EFB, transparent);
    opacity: 0.6;
    animation: dg-scan-line 2s ease-in-out infinite;
  `,e.appendChild(n),!document.getElementById("dg-overlay-keyframes")){const r=document.createElement("style");r.id="dg-overlay-keyframes",r.textContent=`
      @keyframes dg-scan-line {
        0%, 100% { top: 0; }
        50% { top: calc(100% - 2px); }
      }
      @keyframes dg-border-pulse {
        0%, 100% { border-color: #2A7EFB; box-shadow: 0 0 0 1px rgba(42,126,251,0.15), inset 0 0 20px rgba(42,126,251,0.05); }
        50% { border-color: #ef4444; box-shadow: 0 0 12px rgba(239,68,68,0.25), inset 0 0 20px rgba(239,68,68,0.05); }
      }
    `,document.head.appendChild(r)}e.style.animation="dg-border-pulse 3s ease-in-out infinite",document.body.appendChild(e);function o(){if(!y||!u){h=null;return}const r=document.getElementById(ee);if(!r){h=null;return}const a=y.getBoundingClientRect();r.style.left=`${a.left}px`,r.style.top=`${a.top}px`,r.style.width=`${a.width}px`,r.style.height=`${a.height}px`;const s=r.querySelector(".dg-overlay-label");if(s){const c=(a.width/window.innerWidth*100).toFixed(0),_=(a.height/window.innerHeight*100).toFixed(0);s.textContent=`${Math.round(a.width)}×${Math.round(a.height)}px  ·  ${c}% × ${_}% of viewport`}h=requestAnimationFrame(o)}h=requestAnimationFrame(o)}function X(){var e;(e=document.getElementById(ee))==null||e.remove(),h!==null&&(cancelAnimationFrame(h),h=null)}function gt(){u=!u,u&&y?ve():X(),we()}function we(){const e=document.getElementById("dg-overlay-toggle");e&&(e.style.background=u?"rgba(255,255,255,0.25)":"transparent",e.title=u?"Hide capture area":"Show capture area",e.innerHTML=u?'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3" fill="white"/></svg>':'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.6)" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>')}chrome.runtime.onMessage.addListener((e,t,i)=>{switch(e.type){case"SCANNER_ON":le();break;case"SCANNER_OFF":_e();break;case"START_REGION_SELECT":Ye();break;case"START_AUDIO_RECORD":Ke();break;case"START_VIDEO_RECORD":et();break;case"START_CAM_MONITOR":xe();break;case"STOP_CAM_MONITOR":ye();break}return i({ok:!0}),!0});try{chrome.storage.session.get("scannerOn",e=>{chrome.runtime.lastError||e!=null&&e.scannerOn&&le()})}catch{}try{chrome.storage.session.get("camMonitorOn",e=>{chrome.runtime.lastError||e!=null&&e.camMonitorOn&&xe()})}catch{}
